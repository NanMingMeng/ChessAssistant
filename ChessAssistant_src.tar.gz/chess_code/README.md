# 🎯 象棋助手 (Chess Assistant)

一款强大的Android象棋AI辅助工具，能够实时分析《JJ象棋》或《天天象棋》的棋局，并通过悬浮窗显示AI建议的最佳走法。

## ✨ 核心特性

- **实时屏幕捕获** - 使用 MediaProjection API 实时捕获游戏画面
- **智能棋盘识别** - 自动识别棋盘和棋子位置，生成标准FEN格式
- **强力AI分析** - 集成Pikafish引擎，提供专业级别的棋步建议
- **悬浮窗显示** - 以悬浮窗形式显示AI建议，不影响游戏操作
- **后台运行** - 支持后台服务，可在使用其他应用时继续提供分析

## 🛠️ 技术架构

### 核心模块
1. **屏幕捕获模块** (`ScreenCaptureService`) - 负责实时截取游戏画面
2. **棋盘识别模块** (`ChessRecognizer`) - 将截图转化为棋盘状态
3. **AI计算模块** (`PikafishEngine`) - 根据FEN计算最佳走法
4. **UI展示模块** (`FloatingWindowService`) - 以悬浮窗形式显示AI建议

### 技术栈
- **AI引擎**: Pikafish (基于Stockfish的象棋变体)
- **屏幕捕获**: MediaProjection API
- **图像处理**: Android Bitmap API + 自定义识别算法
- **UI**: Android悬浮窗服务
- **构建**: Gradle + Android SDK

## 📁 项目结构

```
ChessAssistant/
├── app/
│   ├── src/main/
│   │   ├── java/com/chessassistant/
│   │   │   ├── MainActivity.java          # 主界面
│   │   │   ├── ChessPiece.java            # 棋子模型
│   │   │   ├── ChessboardState.java       # 棋盘状态
│   │   │   ├── PikafishEngine.java        # AI引擎封装
│   │   │   ├── ChessRecognizer.java       # 棋盘识别器
│   │   │   ├── ScreenCaptureService.java  # 屏幕捕获服务
│   │   │   └── FloatingWindowService.java # 悬浮窗服务
│   │   ├── res/
│   │   │   ├── layout/                    # 布局文件
│   │   │   ├── values/                    # 资源值
│   │   │   └── drawable/                  # 图形资源
│   │   ├── AndroidManifest.xml            # 应用清单
│   │   ├── assets/                        # 资源文件
│   │   └── jniLibs/arm64-v8a/            # 原生库
│   └── build.gradle                       # 模块构建配置
├── build.gradle                           # 项目构建配置
├── extract_pikafish.py                    # Pikafish集成脚本
└── setup_assets.py                        # 资源配置脚本
```

## 🚀 快速开始

### 前提条件
- Android Studio Hedgehog 或更高版本
- Android SDK 34 或更高版本
- 物理Android设备（支持Android 10.0+）

### 构建步骤

1. **下载Pikafish引擎**
   ```bash
   # 下载官方发布包
   wget https://github.com/official-pikafish/Pikafish/releases/download/Pikafish-2026-01-02/Pikafish.2026-01-02.7z
   ```

2. **运行集成脚本**
   ```bash
   python3 extract_pikafish.py
   ```
   或者手动解压并放置文件：
   - 将 `android-arm64/pikafish` 放入 `app/src/main/jniLibs/arm64-v8a/`
   - 将 `.nnue` 神经网络文件放入 `app/src/main/assets/`

3. **在Android Studio中打开项目**
   - 选择 "Open an existing project"
   - 导航到 `ChessAssistant` 目录
   - 等待Gradle同步完成

4. **连接设备并运行**
   - 通过USB连接Android设备
   - 点击 "Run" 按钮
   - 在设备上安装并启动应用

## 📋 使用说明

1. **启动应用** - 打开"象棋助手"应用
2. **授予权限** - 允许屏幕捕获权限
3. **启动服务** - 点击"开始分析"按钮
4. **切换游戏** - 打开《JJ象棋》或《天天象棋》
5. **查看建议** - 悬浮窗将显示AI建议的最佳走法

## 🔧 配置选项

- **AI引擎选择**: 可选择不同版本的Pikafish引擎
- **识别精度**: 调整棋盘识别的灵敏度
- **悬浮窗位置**: 拖动悬浮窗到任意位置
- **更新频率**: 设置AI分析的频率（1-10秒）

## ⚠️ 注意事项

1. **权限要求**: 需要屏幕捕获权限才能正常工作
2. **设备兼容性**: 需要Android 10.0或更高版本
3. **性能要求**: 建议使用性能较好的设备以获得流畅体验
4. **游戏兼容性**: 目前支持《JJ象棋》和《天天象棋》

## 🤝 贡献指南

欢迎贡献代码、报告问题或提出改进建议！

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 🔗 相关资源

- [Pikafish官方仓库](https://github.com/official-pikafish/Pikafish)
- [Android MediaProjection文档](https://developer.android.com/reference/android/media/projection/MediaProjection)
- [Android悬浮窗服务](https://developer.android.com/reference/android/view/WindowManager)

## 📞 联系方式

如有问题或建议，请通过以下方式联系：
- 提交 Issue
- 发送邮件至：[your-email@example.com]

---

**🎯 祝你下棋愉快！**