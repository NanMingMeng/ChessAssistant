package com.chessassistant;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    
    private static final int OVERLAY_PERMISSION_REQUEST = 1234;
    
    private Button btnStart;
    private Button btnStop;
    private TextView tvStatus;
    private TextView tvFen;
    private boolean isRunning = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // 初始化UI组件
        btnStart = findViewById(R.id.btn_start);
        btnStop = findViewById(R.id.btn_stop);
        tvStatus = findViewById(R.id.tv_status);
        tvFen = findViewById(R.id.tv_fen);
        
        // 设置按钮点击事件
        btnStart.setOnClickListener(v -> startService());
        btnStop.setOnClickListener(v -> stopService());
        
        // 初始状态
        tvStatus.setText("就绪 - 点击开始分析");
        btnStop.setEnabled(false);
        
        Toast.makeText(this, "象棋助手 MVP 已启动", Toast.LENGTH_SHORT).show();
    }
    
    private void startService() {
        // 检查悬浮窗权限
        if (!Settings.canDrawOverlays(this)) {
            // 请求悬浮窗权限
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
            return;
        }
        
        // 启动悬浮窗服务
        Intent serviceIntent = new Intent(this, FloatingWindowService.class);
        startForegroundService(serviceIntent);
        
        isRunning = true;
        updateUI();
        
        Toast.makeText(this, "分析服务已启动", Toast.LENGTH_SHORT).show();
    }
    
    private void stopService() {
        Intent serviceIntent = new Intent(this, FloatingWindowService.class);
        stopService(serviceIntent);
        
        isRunning = false;
        updateUI();
        
        Toast.makeText(this, "分析服务已停止", Toast.LENGTH_SHORT).show();
    }
    
    private void updateUI() {
        btnStart.setEnabled(!isRunning);
        btnStop.setEnabled(isRunning);
        
        if (isRunning) {
            tvStatus.setText("正在运行 - 分析棋局中...");
            tvFen.setText("FEN: 等待棋盘识别...");
        } else {
            tvStatus.setText("就绪 - 点击开始分析");
            tvFen.setText("FEN: 未启动分析");
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (Settings.canDrawOverlays(this)) {
                startService();
            } else {
                Toast.makeText(this, "需要悬浮窗权限才能运行", Toast.LENGTH_LONG).show();
            }
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isRunning) {
            stopService();
        }
    }
}