package com.chessassistant.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 棋盘状态模型
 */
public class ChessboardState {
    // 棋盘大小：10行9列
    public static final int ROWS = 10;
    public static final int COLS = 9;
    
    private ChessPiece[][] board = new ChessPiece[ROWS][COLS];
    private char turnToMove = 'w'; // 'w' = 红方, 'b' = 黑方
    private String castlingRights = "-"; // 王车易位权限
    private String enPassantTarget = "-"; // 吃过路兵目标格
    private int halfmoveClock = 0; // 半步时钟
    private int fullmoveNumber = 1; // 总回合数
    
    public ChessboardState() {
        // 初始化空棋盘
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                board[i][j] = null;
            }
        }
    }
    
    /**
     * 设置棋子
     */
    public void setPiece(int row, int col, ChessPiece piece) {
        if (row >= 0 && row < ROWS && col >= 0 && col < COLS) {
            board[row][col] = piece;
        }
    }
    
    /**
     * 获取棋子
     */
    public ChessPiece getPiece(int row, int col) {
        if (row >= 0 && row < ROWS && col >= 0 && col < COLS) {
            return board[row][col];
        }
        return null;
    }
    
    /**
     * 生成FEN字符串
     */
    public String toFEN() {
        StringBuilder fen = new StringBuilder();
        
        // 1. 棋子布局
        for (int row = 0; row < ROWS; row++) {
            int emptyCount = 0;
            for (int col = 0; col < COLS; col++) {
                ChessPiece piece = board[row][col];
                if (piece == null) {
                    emptyCount++;
                } else {
                    if (emptyCount > 0) {
                        fen.append(emptyCount);
                        emptyCount = 0;
                    }
                    fen.append(piece.toFENChar());
                }
            }
            if (emptyCount > 0) {
                fen.append(emptyCount);
            }
            if (row < ROWS - 1) {
                fen.append('/');
            }
        }
        
        // 2. 轮到哪方走
        fen.append(' ').append(turnToMove);
        
        // 3. 王车易位权限
        fen.append(' ').append(castlingRights);
        
        // 4. 吃过路兵目标格
        fen.append(' ').append(enPassantTarget);
        
        // 5. 半步时钟
        fen.append(' ').append(halfmoveClock);
        
        // 6. 总回合数
        fen.append(' ').append(fullmoveNumber);
        
        return fen.toString();
    }
    
    /**
     * 从FEN字符串解析棋盘状态
     */
    public static ChessboardState fromFEN(String fen) {
        ChessboardState state = new ChessboardState();
        String[] parts = fen.split(" ");
        
        // 解析棋子布局
        String[] rows = parts[0].split("/");
        for (int row = 0; row < ROWS; row++) {
            int col = 0;
            for (char c : rows[row].toCharArray()) {
                if (Character.isDigit(c)) {
                    col += Character.getNumericValue(c);
                } else {
                    ChessPiece.PieceType type = fenCharToPieceType(c);
                    ChessPiece.PieceColor color = Character.isUpperCase(c) ? 
                        ChessPiece.PieceColor.RED : ChessPiece.PieceColor.BLACK;
                    state.setPiece(row, col, new ChessPiece(type, color, row, col));
                    col++;
                }
            }
        }
        
        // 解析其他信息
        if (parts.length > 1) state.turnToMove = parts[1].charAt(0);
        if (parts.length > 2) state.castlingRights = parts[2];
        if (parts.length > 3) state.enPassantTarget = parts[3];
        if (parts.length > 4) state.halfmoveClock = Integer.parseInt(parts[4]);
        if (parts.length > 5) state.fullmoveNumber = Integer.parseInt(parts[5]);
        
        return state;
    }
    
    private static ChessPiece.PieceType fenCharToPieceType(char c) {
        switch (c) {
            case 'K': return ChessPiece.PieceType.R_KING;
            case 'A': return ChessPiece.PieceType.R_ADVISOR;
            case 'B': return ChessPiece.PieceType.R_ELEPHANT;
            case 'N': return ChessPiece.PieceType.R_HORSE;
            case 'R': return ChessPiece.PieceType.R_ROOK;
            case 'C': return ChessPiece.PieceType.R_CANNON;
            case 'P': return ChessPiece.PieceType.R_PAWN;
            case 'k': return ChessPiece.PieceType.B_KING;
            case 'a': return ChessPiece.PieceType.B_ADVISOR;
            case 'b': return ChessPiece.PieceType.B_ELEPHANT;
            case 'n': return ChessPiece.PieceType.B_HORSE;
            case 'r': return ChessPiece.PieceType.B_ROOK;
            case 'c': return ChessPiece.PieceType.B_CANNON;
            case 'p': return ChessPiece.PieceType.B_PAWN;
            default: return null;
        }
    }
    
    // Getters and Setters
    public char getTurnToMove() {
        return turnToMove;
    }
    
    public void setTurnToMove(char turnToMove) {
        this.turnToMove = turnToMove;
    }
    
    public String getCastlingRights() {
        return castlingRights;
    }
    
    public void setCastlingRights(String castlingRights) {
        this.castlingRights = castlingRights;
    }
    
    public String getEnPassantTarget() {
        return enPassantTarget;
    }
    
    public void setEnPassantTarget(String enPassantTarget) {
        this.enPassantTarget = enPassantTarget;
    }
    
    public int getHalfmoveClock() {
        return halfmoveClock;
    }
    
    public void setHalfmoveClock(int halfmoveClock) {
        this.halfmoveClock = halfmoveClock;
    }
    
    public int getFullmoveNumber() {
        return fullmoveNumber;
    }
    
    public void setFullmoveNumber(int fullmoveNumber) {
        this.fullmoveNumber = fullmoveNumber;
    }
    
    /**
     * 获取所有棋子
     */
    public List<ChessPiece> getAllPieces() {
        List<ChessPiece> pieces = new ArrayList<>();
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                if (board[row][col] != null) {
                    pieces.add(board[row][col]);
                }
            }
        }
        return pieces;
    }
    
    /**
     * 克隆棋盘状态
     */
    public ChessboardState clone() {
        ChessboardState newState = new ChessboardState();
        newState.turnToMove = this.turnToMove;
        newState.castlingRights = this.castlingRights;
        newState.enPassantTarget = this.enPassantTarget;
        newState.halfmoveClock = this.halfmoveClock;
        newState.fullmoveNumber = this.fullmoveNumber;
        
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                if (board[row][col] != null) {
                    newState.board[row][col] = new ChessPiece(
                        board[row][col].getType(),
                        board[row][col].getColor(),
                        row, col
                    );
                }
            }
        }
        return newState;
    }
}
