package com.chessassistant.model;

/**
 * 象棋棋子模型
 */
public class ChessPiece {
    public enum PieceType {
        // 红方棋子
        R_KING, R_ADVISOR, R_ELEPHANT, R_HORSE, R_ROOK, R_CANNON, R_PAWN,
        // 黑方棋子
        B_KING, B_ADVISOR, B_ELEPHANT, B_HORSE, B_ROOK, B_CANNON, B_PAWN
    }

    public enum PieceColor {
        RED, BLACK
    }

    private PieceType type;
    private PieceColor color;
    private int row;
    private int col;

    public ChessPiece(PieceType type, PieceColor color, int row, int col) {
        this.type = type;
        this.color = color;
        this.row = row;
        this.col = col;
    }

    // Getters and Setters
    public PieceType getType() {
        return type;
    }

    public void setType(PieceType type) {
        this.type = type;
    }

    public PieceColor getColor() {
        return color;
    }

    public void setColor(PieceColor color) {
        this.color = color;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    /**
     * 转换为FEN字符
     */
    public char toFENChar() {
        char c;
        switch (type) {
            case R_KING: c = 'K'; break;
            case R_ADVISOR: c = 'A'; break;
            case R_ELEPHANT: c = 'B'; break;
            case R_HORSE: c = 'N'; break;
            case R_ROOK: c = 'R'; break;
            case R_CANNON: c = 'C'; break;
            case R_PAWN: c = 'P'; break;
            case B_KING: c = 'k'; break;
            case B_ADVISOR: c = 'a'; break;
            case B_ELEPHANT: c = 'b'; break;
            case B_HORSE: c = 'n'; break;
            case B_ROOK: c = 'r'; break;
            case B_CANNON: c = 'c'; break;
            case B_PAWN: c = 'p'; break;
            default: c = '?';
        }
        return c;
    }
}
