package com.chessassistant.engine;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Pikafish象棋引擎封装类
 */
public class PikafishEngine {
    private static final String TAG = "PikafishEngine";
    private static final String ENGINE_BINARY = "pikafish";
    
    private long enginePtr = 0;
    private boolean isInitialized = false;
    private Process engineProcess = null;
    
    static {
        System.loadLibrary("pikafish_jni");
    }
    
    // JNI native methods
    private native long nativeInit(String enginePath);
    private native void nativeSetPosition(long enginePtr, String fen);
    private native String nativeGo(long enginePtr, int depth);
    private native int nativeEval(long enginePtr);
    private native void nativeDestroy(long enginePtr);
    
    /**
     * 初始化引擎
     */
    public boolean init(Context context) {
        if (isInitialized) {
            return true;
        }
        
        try {
            // 1. 复制引擎二进制文件到内部存储
            String enginePath = copyEngineToInternal(context);
            if (enginePath == null) {
                Log.e(TAG, "Failed to copy engine binary");
                return false;
            }
            
            // 2. 设置执行权限
            File engineFile = new File(enginePath);
            engineFile.setExecutable(true);
            
            // 3. 初始化JNI
            enginePtr = nativeInit(enginePath);
            if (enginePtr == 0) {
                Log.e(TAG, "Failed to initialize engine via JNI");
                // 尝试通过进程方式启动
                return initViaProcess(enginePath);
            }
            
            isInitialized = true;
            Log.i(TAG, "Pikafish engine initialized successfully");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Error initializing engine", e);
            return false;
        }
    }
    
    /**
     * 通过进程方式初始化引擎（备用方案）
     */
    private boolean initViaProcess(String enginePath) {
        try {
            ProcessBuilder pb = new ProcessBuilder(enginePath);
            pb.redirectErrorStream(true);
            engineProcess = pb.start();
            isInitialized = true;
            Log.i(TAG, "Engine started via process");
            return true;
        } catch (IOException e) {
            Log.e(TAG, "Failed to start engine process", e);
            return false;
        }
    }
    
    /**
     * 复制引擎文件到内部存储
     */
    private String copyEngineToInternal(Context context) {
        try {
            File engineDir = new File(context.getFilesDir(), "engines");
            if (!engineDir.exists()) {
                engineDir.mkdirs();
            }
            
            File engineFile = new File(engineDir, ENGINE_BINARY);
            
            // 如果文件已存在，检查是否需要更新
            if (engineFile.exists()) {
                return engineFile.getAbsolutePath();
            }
            
            // 从assets复制
            InputStream is = context.getAssets().open(ENGINE_BINARY);
            OutputStream os = new FileOutputStream(engineFile);
            
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
            
            is.close();
            os.close();
            
            return engineFile.getAbsolutePath();
            
        } catch (IOException e) {
            Log.e(TAG, "Error copying engine file", e);
            return null;
        }
    }
    
    /**
     * 设置棋局位置
     */
    public void setPosition(String fen) {
        if (!isInitialized) {
            Log.e(TAG, "Engine not initialized");
            return;
        }
        
        if (enginePtr != 0) {
            nativeSetPosition(enginePtr, fen);
        }
        // 如果使用进程方式，通过stdin发送命令
    }
    
    /**
     * 搜索最佳走法
     */
    public String go(int depth) {
        if (!isInitialized) {
            Log.e(TAG, "Engine not initialized");
            return null;
        }
        
        if (enginePtr != 0) {
            return nativeGo(enginePtr, depth);
        }
        
        return null;
    }
    
    /**
     * 获取当前局面评估分数
     */
    public int evaluate() {
        if (!isInitialized) {
            Log.e(TAG, "Engine not initialized");
            return 0;
        }
        
        if (enginePtr != 0) {
            return nativeEval(enginePtr);
        }
        
        return 0;
    }
    
    /**
     * 分析局面并返回结果
     */
    public AnalysisResult analyze(String fen, int depth) {
        setPosition(fen);
        String bestMove = go(depth);
        int score = evaluate();
        
        AnalysisResult result = new AnalysisResult();
        result.bestMove = bestMove;
        result.score = score;
        result.depth = depth;
        
        return result;
    }
    
    /**
     * 销毁引擎
     */
    public void destroy() {
        if (enginePtr != 0) {
            nativeDestroy(enginePtr);
            enginePtr = 0;
        }
        
        if (engineProcess != null) {
            engineProcess.destroy();
            engineProcess = null;
        }
        
        isInitialized = false;
        Log.i(TAG, "Engine destroyed");
    }
    
    /**
     * 分析结果类
     */
    public static class AnalysisResult {
        public String bestMove;
        public int score;
        public int depth;
        
        @Override
        public String toString() {
            return String.format("Best move: %s, Score: %d, Depth: %d", 
                bestMove, score, depth);
        }
    }
}
