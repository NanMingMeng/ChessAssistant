package com.chessassistant.service;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import androidx.core.app.NotificationCompat;

import com.chessassistant.MainActivity;
import com.chessassistant.R;
import com.chessassistant.recognizer.ChessRecognizer;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 屏幕捕获服务 - 实时捕获游戏画面并识别棋盘
 */
public class ScreenCaptureService extends Service {
    private static final String TAG = "ScreenCaptureService";
    private static final String CHANNEL_ID = "ChessAssistantChannel";
    private static final int NOTIFICATION_ID = 1001;
    
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private WindowManager windowManager;
    
    private ChessRecognizer recognizer;
    private Handler mainHandler;
    private ExecutorService executorService;
    
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;
    
    private boolean isCapturing = false;
    private long lastCaptureTime = 0;
    private static final long CAPTURE_INTERVAL = 1000; // 每秒捕获一次
    
    public interface OnChessboardRecognizedListener {
        void onChessboardRecognized(String fen, String bestMove, int score);
        void onError(String error);
    }
    
    private OnChessboardRecognizedListener listener;
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        // 初始化组件
        recognizer = new ChessRecognizer();
        mainHandler = new Handler(Looper.getMainLooper());
        executorService = Executors.newSingleThreadExecutor();
        
        // 获取屏幕信息
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(metrics);
        
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDensity = metrics.densityDpi;
        
        // 创建通知渠道
        createNotificationChannel();
        
        Log.i(TAG, "ScreenCaptureService created");
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        
        // 获取MediaProjection数据
        int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data = intent.getParcelableExtra("data");
        
        if (resultCode != Activity.RESULT_OK || data == null) {
            Log.e(TAG, "Invalid capture parameters");
            stopSelf();
            return START_NOT_STICKY;
        }
        
        // 启动前台服务
        startForeground(NOTIFICATION_ID, createNotification());
        
        // 初始化MediaProjection
        MediaProjectionManager projectionManager = 
            (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mediaProjection = projectionManager.getMediaProjection(resultCode, data);
        
        if (mediaProjection == null) {
            Log.e(TAG, "Failed to create MediaProjection");
            stopSelf();
            return START_NOT_STICKY;
        }
        
        // 设置回调
        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                Log.i(TAG, "MediaProjection stopped");
                stopCapture();
            }
        }, mainHandler);
        
        // 开始捕获
        startCapture();
        
        return START_STICKY;
    }
    
    /**
     * 开始屏幕捕获
     */
    private void startCapture() {
        if (isCapturing) {
            return;
        }
        
        try {
            // 创建ImageReader
            imageReader = ImageReader.newInstance(
                screenWidth, screenHeight, 
                PixelFormat.RGBA_8888, 
                2
            );
            
            imageReader.setOnImageAvailableListener(reader -> {
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastCaptureTime < CAPTURE_INTERVAL) {
                    return;
                }
                
                Image image = reader.acquireLatestImage();
                if (image != null) {
                    lastCaptureTime = currentTime;
                    processImage(image);
                    image.close();
                }
            }, mainHandler);
            
            // 创建VirtualDisplay
            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ChessCapture",
                screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null, mainHandler
            );
            
            isCapturing = true;
            Log.i(TAG, "Screen capture started");
            
        } catch (Exception e) {
            Log.e(TAG, "Error starting capture", e);
            stopCapture();
        }
    }
    
    /**
     * 处理捕获的图像
     */
    private void processImage(Image image) {
        executorService.execute(() -> {
            try {
                // 转换为Bitmap
                Bitmap bitmap = imageToBitmap(image);
                if (bitmap == null) {
                    return;
                }
                
                // 识别棋盘
                com.chessassistant.model.ChessboardState state = 
                    recognizer.recognizeChessboard(bitmap);
                
                if (state != null) {
                    // 生成FEN
                    String fen = state.toFEN();
                    
                    // TODO: 调用AI引擎分析
                    String bestMove = "e0e9"; // 临时占位
                    int score = 0;
                    
                    // 通知主线程
                    mainHandler.post(() -> {
                        if (listener != null) {
                            listener.onChessboardRecognized(fen, bestMove, score);
                        }
                    });
                }
                
                bitmap.recycle();
                
            } catch (Exception e) {
                Log.e(TAG, "Error processing image", e);
            }
        });
    }
    
    /**
     * 将Image转换为Bitmap
     */
    private Bitmap imageToBitmap(Image image) {
        try {
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * screenWidth;
            
            Bitmap bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            );
            bitmap.copyPixelsFromBuffer(buffer);
            
            // 裁剪到正确大小
            return Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
            
        } catch (Exception e) {
            Log.e(TAG, "Error converting image to bitmap", e);
            return null;
        }
    }
    
    /**
     * 停止捕获
     */
    public void stopCapture() {
        isCapturing = false;
        
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
        
        Log.i(TAG, "Screen capture stopped");
    }
    
    /**
     * 设置识别结果监听器
     */
    public void setOnChessboardRecognizedListener(OnChessboardRecognizedListener listener) {
        this.listener = listener;
    }
    
    /**
     * 创建通知渠道
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Chess Assistant Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("屏幕捕获服务运行中");
            
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
    
    /**
     * 创建前台通知
     */
    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent, 
            PendingIntent.FLAG_IMMUTABLE
        );
        
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("象棋助手")
            .setContentText("正在监听棋局...")
            .setSmallIcon(R.drawable.ic_chess)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build();
    }
    
    @Override
    public void onDestroy() {
        stopCapture();
        if (executorService != null) {
            executorService.shutdown();
        }
        super.onDestroy();
        Log.i(TAG, "ScreenCaptureService destroyed");
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    /**
     * 启动屏幕捕获的静态方法
     */
    public static void start(Context context, int resultCode, Intent data) {
        Intent serviceIntent = new Intent(context, ScreenCaptureService.class);
        serviceIntent.putExtra("resultCode", resultCode);
        serviceIntent.putExtra("data", data);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }
    
    /**
     * 停止屏幕捕获的静态方法
     */
    public static void stop(Context context) {
        context.stopService(new Intent(context, ScreenCaptureService.class));
    }
}
