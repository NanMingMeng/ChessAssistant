package com.chessassistant.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.chessassistant.R;

/**
 * 悬浮窗服务 - 显示AI分析结果
 */
public class FloatingWindowService extends Service {
    private static final String TAG = "FloatingWindowService";
    
    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams layoutParams;
    
    private TextView tvBestMove;
    private TextView tvScore;
    private TextView tvFEN;
    private Button btnClose;
    private Button btnMinimize;
    
    private boolean isMinimized = false;
    private int initialX, initialY;
    private float initialTouchX, initialTouchY;
    
    private Handler mainHandler;
    
    public interface OnFloatingWindowClickListener {
        void onCloseClick();
        void onMinimizeClick();
        void onWindowClick();
    }
    
    private OnFloatingWindowClickListener clickListener;
    
    @Override
    public void onCreate() {
        super.onCreate();
        mainHandler = new Handler(Looper.getMainLooper());
        
        // 获取WindowManager
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        
        // 创建悬浮窗视图
        createFloatingView();
        
        Log.i(TAG, "FloatingWindowService created");
    }
    
    /**
     * 创建悬浮窗视图
     */
    private void createFloatingView() {
        // 加载布局
        LayoutInflater inflater = LayoutInflater.from(this);
        floatingView = inflater.inflate(R.layout.floating_window, null);
        
        // 初始化视图组件
        tvBestMove = floatingView.findViewById(R.id.tv_best_move);
        tvScore = floatingView.findViewById(R.id.tv_score);
        tvFEN = floatingView.findViewById(R.id.tv_fen);
        btnClose = floatingView.findViewById(R.id.btn_close);
        btnMinimize = floatingView.findViewById(R.id.btn_minimize);
        
        // 设置点击事件
        btnClose.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onCloseClick();
            }
            stopSelf();
        });
        
        btnMinimize.setOnClickListener(v -> {
            isMinimized = !isMinimized;
            updateViewVisibility();
            if (clickListener != null) {
                clickListener.onMinimizeClick();
            }
        });
        
        // 设置窗口参数
        int windowType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            windowType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            windowType = WindowManager.LayoutParams.TYPE_PHONE;
        }
        
        layoutParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        
        // 初始位置：右上角
        layoutParams.gravity = Gravity.TOP | Gravity.END;
        layoutParams.x = 20;
        layoutParams.y = 100;
        
        // 添加到窗口
        windowManager.addView(floatingView, layoutParams);
        
        // 设置拖动事件
        setupDragListener();
        
        // 设置点击事件
        floatingView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onWindowClick();
            }
        });
        
        // 初始状态：最小化
        isMinimized = true;
        updateViewVisibility();
    }
    
    /**
     * 设置拖动监听器
     */
    private void setupDragListener() {
        floatingView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = layoutParams.x;
                    initialY = layoutParams.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;
                    
                case MotionEvent.ACTION_MOVE:
                    layoutParams.x = initialX - (int) (event.getRawX() - initialTouchX);
                    layoutParams.y = initialY + (int) (event.getRawY() - initialTouchY);
                    windowManager.updateViewLayout(floatingView, layoutParams);
                    return true;
                    
                case MotionEvent.ACTION_UP:
                    // 检查是否是点击（移动距离很小）
                    float deltaX = Math.abs(event.getRawX() - initialTouchX);
                    float deltaY = Math.abs(event.getRawY() - initialTouchY);
                    if (deltaX < 10 && deltaY < 10) {
                        // 是点击，不是拖动
                        v.performClick();
                    }
                    return true;
            }
            return false;
        });
    }
    
    /**
     * 更新视图可见性
     */
    private void updateViewVisibility() {
        if (isMinimized) {
            // 最小化：只显示一个小图标
            layoutParams.width = 100;
            layoutParams.height = 100;
            
            // 隐藏详细信息
            tvBestMove.setVisibility(View.GONE);
            tvScore.setVisibility(View.GONE);
            tvFEN.setVisibility(View.GONE);
            btnMinimize.setText("▲");
        } else {
            // 展开：显示完整信息
            layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
            
            // 显示详细信息
            tvBestMove.setVisibility(View.VISIBLE);
            tvScore.setVisibility(View.VISIBLE);
            tvFEN.setVisibility(View.VISIBLE);
            btnMinimize.setText("▼");
        }
        
        windowManager.updateViewLayout(floatingView, layoutParams);
    }
    
    /**
     * 更新显示内容
     */
    public void updateDisplay(String bestMove, int score, String fen) {
        mainHandler.post(() -> {
            if (tvBestMove != null) {
                tvBestMove.setText("推荐走法: " + bestMove);
            }
            
            if (tvScore != null) {
                tvScore.setText("评估分数: " + score);
            }
            
            if (tvFEN != null) {
                // 只显示FEN前20个字符，避免太长
                String shortFen = fen.length() > 20 ? 
                    fen.substring(0, 20) + "..." : fen;
                tvFEN.setText("局面: " + shortFen);
            }
        });
    }
    
    /**
     * 设置点击监听器
     */
    public void setOnFloatingWindowClickListener(OnFloatingWindowClickListener listener) {
        this.clickListener = listener;
    }
    
    /**
     * 显示/隐藏悬浮窗
     */
    public void show() {
        if (floatingView != null) {
            floatingView.setVisibility(View.VISIBLE);
        }
    }
    
    public void hide() {
        if (floatingView != null) {
            floatingView.setVisibility(View.GONE);
        }
    }
    
    /**
     * 移动悬浮窗位置
     */
    public void moveTo(int x, int y) {
        layoutParams.x = x;
        layoutParams.y = y;
        windowManager.updateViewLayout(floatingView, layoutParams);
    }
    
    /**
     * 切换最小化状态
     */
    public void toggleMinimize() {
        isMinimized = !isMinimized;
        updateViewVisibility();
    }
    
    @Override
    public void onDestroy() {
        if (floatingView != null) {
            windowManager.removeView(floatingView);
        }
        super.onDestroy();
        Log.i(TAG, "FloatingWindowService destroyed");
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    /**
     * 启动悬浮窗的静态方法
     */
    public static void start(Context context) {
        Intent serviceIntent = new Intent(context, FloatingWindowService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }
    
    /**
     * 停止悬浮窗的静态方法
     */
    public static void stop(Context context) {
        context.stopService(new Intent(context, FloatingWindowService.class));
    }
}
