package com.chessassistant.recognizer;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;
import com.chessassistant.model.ChessPiece;
import com.chessassistant.model.ChessboardState;
import java.util.ArrayList;
import java.util.List;

/**
 * 棋盘识别器 - 从图像中识别棋盘状态
 */
public class ChessRecognizer {
    private static final String TAG = "ChessRecognizer";
    
    // 棋盘标准尺寸（10行9列）
    private static final int BOARD_ROWS = 10;
    private static final int BOARD_COLS = 9;
    
    // 颜色阈值
    private static final int COLOR_THRESHOLD = 50;
    
    /**
     * 从图像识别棋盘状态
     */
    public ChessboardState recognizeChessboard(Bitmap bitmap) {
        if (bitmap == null) {
            Log.e(TAG, "Input bitmap is null");
            return null;
        }
        
        try {
            // 1. 检测棋盘边界
            int[] boardRect = detectBoardBoundary(bitmap);
            if (boardRect == null) {
                Log.e(TAG, "Failed to detect board boundary");
                return null;
            }
            
            // 2. 计算网格单元格大小
            int cellWidth = (boardRect[2] - boardRect[0]) / BOARD_COLS;
            int cellHeight = (boardRect[3] - boardRect[1]) / BOARD_ROWS;
            
            // 3. 创建棋盘状态
            ChessboardState state = new ChessboardState();
            
            // 4. 识别每个格子
            for (int row = 0; row < BOARD_ROWS; row++) {
                for (int col = 0; col < BOARD_COLS; col++) {
                    // 计算格子中心坐标
                    int centerX = boardRect[0] + col * cellWidth + cellWidth / 2;
                    int centerY = boardRect[1] + row * cellHeight + cellHeight / 2;
                    
                    // 识别棋子
                    ChessPiece piece = recognizePiece(bitmap, centerX, centerY, cellWidth, cellHeight);
                    if (piece != null) {
                        state.setPiece(row, col, piece);
                    }
                }
            }
            
            Log.i(TAG, "Chessboard recognized successfully");
            return state;
            
        } catch (Exception e) {
            Log.e(TAG, "Error recognizing chessboard", e);
            return null;
        }
    }
    
    /**
     * 检测棋盘边界
     */
    private int[] detectBoardBoundary(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        
        // 扫描图像寻找棋盘边界
        int top = 0, bottom = height - 1, left = 0, right = width - 1;
        
        // 简单边缘检测（实际应使用更复杂的算法）
        boolean foundTop = false, foundBottom = false;
        boolean foundLeft = false, foundRight = false;
        
        // 从上到下扫描
        for (int y = 0; y < height && !foundTop; y++) {
            for (int x = 0; x < width; x++) {
                int pixel = bitmap.getPixel(x, y);
                if (isBoardEdge(pixel)) {
                    top = y;
                    foundTop = true;
                    break;
                }
            }
        }
        
        // 从下到上扫描
        for (int y = height - 1; y >= 0 && !foundBottom; y--) {
            for (int x = 0; x < width; x++) {
                int pixel = bitmap.getPixel(x, y);
                if (isBoardEdge(pixel)) {
                    bottom = y;
                    foundBottom = true;
                    break;
                }
            }
        }
        
        // 从左到右扫描
        for (int x = 0; x < width && !foundLeft; x++) {
            for (int y = 0; y < height; y++) {
                int pixel = bitmap.getPixel(x, y);
                if (isBoardEdge(pixel)) {
                    left = x;
                    foundLeft = true;
                    break;
                }
            }
        }
        
        // 从右到左扫描
        for (int x = width - 1; x >= 0 && !foundRight; x--) {
            for (int y = 0; y < height; y++) {
                int pixel = bitmap.getPixel(x, y);
                if (isBoardEdge(pixel)) {
                    right = x;
                    foundRight = true;
                    break;
                }
            }
        }
        
        if (foundTop && foundBottom && foundLeft && foundRight) {
            return new int[]{left, top, right, bottom};
        }
        
        return null;
    }
    
    /**
     * 判断像素是否为棋盘边缘
     */
    private boolean isBoardEdge(int pixel) {
        int red = Color.red(pixel);
        int green = Color.green(pixel);
        int blue = Color.blue(pixel);
        
        // 棋盘边缘通常是深色或特定颜色
        // 这里简化判断：如果颜色较深或接近木色
        int brightness = (red + green + blue) / 3;
        
        // 深色边缘
        if (brightness < 80) {
            return true;
        }
        
        // 木色边缘（棋盘颜色）
        if (red > 100 && green > 80 && blue > 50 && 
            Math.abs(red - green) < 50 && Math.abs(green - blue) < 50) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 识别指定位置的棋子
     */
    private ChessPiece recognizePiece(Bitmap bitmap, int centerX, int centerY, 
                                     int cellWidth, int cellHeight) {
        // 1. 提取格子区域
        int left = centerX - cellWidth / 2;
        int top = centerY - cellHeight / 2;
        int right = centerX + cellWidth / 2;
        int bottom = centerY + cellHeight / 2;
        
        // 确保坐标在图像范围内
        left = Math.max(0, left);
        top = Math.max(0, top);
        right = Math.min(bitmap.getWidth() - 1, right);
        bottom = Math.min(bitmap.getHeight() - 1, bottom);
        
        // 2. 采样颜色
        List<Integer> colors = new ArrayList<>();
        for (int y = top; y <= bottom; y += 3) {
            for (int x = left; x <= right; x += 3) {
                colors.add(bitmap.getPixel(x, y));
            }
        }
        
        // 3. 分析颜色分布
        int redCount = 0, blackCount = 0, backgroundCount = 0;
        
        for (int color : colors) {
            int red = Color.red(color);
            int green = Color.green(color);
            int blue = Color.blue(color);
            
            // 判断颜色类型
            if (isRedPieceColor(red, green, blue)) {
                redCount++;
            } else if (isBlackPieceColor(red, green, blue)) {
                blackCount++;
            } else if (isBackgroundColor(red, green, blue)) {
                backgroundCount++;
            }
        }
        
        // 4. 判断棋子类型
        int totalPixels = colors.size();
        double redRatio = (double) redCount / totalPixels;
        double blackRatio = (double) blackCount / totalPixels;
        
        // 如果有足够多的棋子颜色像素
        if (redRatio > 0.3) {
            // 红色棋子
            return createRedPiece(centerX, centerY, bitmap.getWidth(), bitmap.getHeight());
        } else if (blackRatio > 0.3) {
            // 黑色棋子
            return createBlackPiece(centerX, centerY, bitmap.getWidth(), bitmap.getHeight());
        }
        
        return null; // 空格子
    }
    
    /**
     * 判断是否为红色棋子颜色
     */
    private boolean isRedPieceColor(int red, int green, int blue) {
        // 红色棋子通常：高红色，低绿色，低蓝色
        return red > 150 && green < 100 && blue < 100 && (red - green) > 50;
    }
    
    /**
     * 判断是否为黑色棋子颜色
     */
    private boolean isBlackPieceColor(int red, int green, int blue) {
        // 黑色棋子通常：低红色，低绿色，低蓝色
        int brightness = (red + green + blue) / 3;
        return brightness < 80 && Math.abs(red - green) < 30 && Math.abs(green - blue) < 30;
    }
    
    /**
     * 判断是否为背景颜色（棋盘）
     */
    private boolean isBackgroundColor(int red, int green, int blue) {
        // 棋盘背景通常是木色或浅色
        int brightness = (red + green + blue) / 3;
        return brightness > 150 && Math.abs(red - green) < 40 && Math.abs(green - blue) < 40;
    }
    
    /**
     * 创建红色棋子（简化版，实际应根据位置判断具体棋子）
     */
    private ChessPiece createRedPiece(int x, int y, int imageWidth, int imageHeight) {
        // 简化：根据位置推断棋子类型
        // 实际应该使用模板匹配或机器学习
        double normalizedX = (double) x / imageWidth;
        double normalizedY = (double) y / imageHeight;
        
        ChessPiece.PieceType type;
        
        if (normalizedY < 0.3) {
            // 上方区域（黑方阵地）
            if (normalizedX < 0.2 || normalizedX > 0.8) type = ChessPiece.PieceType.R_ROOK;
            else if (normalizedX < 0.4 || normalizedX > 0.6) type = ChessPiece.PieceType.R_HORSE;
            else type = ChessPiece.PieceType.R_ADVISOR;
        } else if (normalizedY > 0.7) {
            // 下方区域（红方阵地）
            if (normalizedX < 0.2 || normalizedX > 0.8) type = ChessPiece.PieceType.R_ROOK;
            else if (normalizedX < 0.4 || normalizedX > 0.6) type = ChessPiece.PieceType.R_HORSE;
            else type = ChessPiece.PieceType.R_ADVISOR;
        } else {
            // 中间区域
            type = ChessPiece.PieceType.R_PAWN;
        }
        
        // 计算棋盘坐标
        int row = (int) (normalizedY * 10);
        int col = (int) (normalizedX * 9);
        
        return new ChessPiece(type, ChessPiece.PieceColor.RED, row, col);
    }
    
    /**
     * 创建黑色棋子（简化版）
     */
    private ChessPiece createBlackPiece(int x, int y, int imageWidth, int imageHeight) {
        double normalizedX = (double) x / imageWidth;
        double normalizedY = (double) y / imageHeight;
        
        ChessPiece.PieceType type;
        
        if (normalizedY < 0.3) {
            // 上方区域（黑方阵地）
            if (normalizedX < 0.2 || normalizedX > 0.8) type = ChessPiece.PieceType.B_ROOK;
            else if (normalizedX < 0.4 || normalizedX > 0.6) type = ChessPiece.PieceType.B_HORSE;
            else type = ChessPiece.PieceType.B_ADVISOR;
        } else if (normalizedY > 0.7) {
            // 下方区域（红方阵地）
            if (normalizedX < 0.2 || normalizedX > 0.8) type = ChessPiece.PieceType.B_ROOK;
            else if (normalizedX < 0.4 || normalizedX > 0.6) type = ChessPiece.PieceType.B_HORSE;
            else type = ChessPiece.PieceType.B_ADVISOR;
        } else {
            // 中间区域
            type = ChessPiece.PieceType.B_PAWN;
        }
        
        int row = (int) (normalizedY * 10);
        int col = (int) (normalizedX * 9);
        
        return new ChessPiece(type, ChessPiece.PieceColor.BLACK, row, col);
    }
    
    /**
     * 改进的棋盘识别（使用模板匹配）
     */
    public ChessboardState recognizeWithTemplate(Bitmap bitmap) {
        // TODO: 实现基于模板匹配的识别
        // 1. 加载棋子模板
        // 2. 模板匹配每个格子
        // 3. 返回识别结果
        
        Log.i(TAG, "Template matching recognition not implemented yet");
        return recognizeChessboard(bitmap); // 暂时使用简单方法
    }
    
    /**
     * 使用颜色直方图改进识别
     */
    public ChessboardState recognizeWithHistogram(Bitmap bitmap) {
        // TODO: 实现基于颜色直方图的识别
        // 1. 计算颜色直方图
        // 2. 分类棋子
        // 3. 返回识别结果
        
        Log.i(TAG, "Histogram recognition not implemented yet");
        return recognizeChessboard(bitmap); // 暂时使用简单方法
    }
}
